<?php

/*
 * Plugin Name: Arion Coin Payment Gateway
 * Plugin URI:
 * Description: Take Payments In Arion Coin Cryptocurrency
 * Author: Therushin Chetty
 * Author URI:
 * Version: 1.0.5
 * Tested Up To WordPress Version: 4.9.8
 * Tested Up To WooCommerce Version: 3.4
 */


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter('woocommerce_payment_gateways', 'ariongwp_add_gateway_class');

function ariongwp_add_gateway_class($gateways) {
    $gateways[] = 'WC_Ariongwp_Gateway'; // your class name is here
    return $gateways;
}

/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action('plugins_loaded', 'ariongwp_init_gateway_class');

function ariongwp_init_gateway_class() {

    class WC_Ariongwp_Gateway extends WC_Payment_Gateway {

        /**
         * Class constructor, more about it in Step 3
         */
        public function __construct() {
            $this->id = 'arioncoinid'; // payment gateway plugin ID
            $this->icon = ''; // URL of the icon that will be displayed on checkout page near your gateway name
            $this->has_fields = true; // in case you need a custom credit card form
            $this->method_title = 'Arion Coin Payment Gateway';
            $this->method_description = 'Take Payments In Arion Coin Cryptocurrency. Offline Payment Gateway.'; // will be displayed on the options page

            $this->supports = array(
                'products'
            );

            // Method with all the options fields
            $this->init_form_fields();

            // Load the settings.
            $this->init_settings();
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->markup = $this->get_option('markup');
            $this->enabled = $this->get_option('enabled');
            $this->arion_wallet_address = $this->get_option('arion_wallet_address');
            $this->cmc_api_key = $this->get_option('cmc_api_key');
            $this->testmode = 'yes' === $this->get_option('testmode');
            $this->private_key = $this->testmode ? $this->get_option('test_private_key') : $this->get_option('private_key');
            $this->publishable_key = $this->testmode ? $this->get_option('test_publishable_key') : $this->get_option('publishable_key');

            // This action hook saves the settings
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            // We need custom JavaScript
	    add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
                       
        }

        /**
         * Plugin options
         */
        public function init_form_fields() {

            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'label' => 'Enable Arion Coin Payment Gateway',
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no'
                ),
                'title' => array(
                    'title' => 'Title',
                    'type' => 'text',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default' => 'Arion Coin',
                ),
                'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default' => 'Make your Arion Coin payment directly into our Arion wallet address. Your order will be processed after funds have cleared in our account.',
                ),
                'markup' => array(
                    'title' => 'Arion Coin Markup %',
                    'type' => 'number',
                    'description' => 'This controls the markup of arion coin added on to checkout total. (e.g 5 for 5% or 10 for 10%...)',
                    'default' => 0,
                ),
                'arion_wallet_address' => array(
                    'title' => 'Arion Coin Wallet Address',
                    'type' => 'text',
                    'description' => 'This saves your arion coin addresss where you recieve payments.',
                    'autocomplete' => 'off',
                ),
                'cmc_api_key' => array(
                    'title' => 'Coinmarketcap Api Key',
                    'type' => 'text',
                    'description' => 'Get your free api key at: https://pro.coinmarketcap.com and copy and paste it in the box above',
                    'autocomplete' => 'off'
                )
            );
        }
        

        /**
         * You will need it if you want your custom arion coin form
         */
        public function payment_fields() {
            global $woocommerce;
            if (is_ajax()) {
            $arion_value_in_cur = $this->get_arion_from_api();
            }
            $cart_total = $woocommerce->cart->total;
            $cart_subtotal = $woocommerce->cart->subtotal;
            
            $acMarkup = $this->markup;
            
            $get_markup_total = (($cart_subtotal*$acMarkup)/100);
            
            $grand_total_in_arion = round((($cart_total + $get_markup_total) / $arion_value_in_cur),8);
            
            $currency_symbol = get_woocommerce_currency_symbol();
            $acAdd = $this->arion_wallet_address;
            
            echo '<style>.user_arion_address_input::placeholder{color:lightgrey} '
                    . '.payment_box.payment_method_arioncoinid{background:#23282D !important; padding: 2em} '
                    . 'input[type="text"]{background-color:#fff}'
                    . '.arion_payment_header{margin-top:15px !important}'
                    . '.arion_payment_details_form hr{background-color:#00ffc6} '
                    . '.arion_payment_details_form p{color:#fff} '
                    . '.arion_payment_details_form p label{color:#fff !important;cursor: text;font-weight: 800 !important;padding:0 !important;}'
                    . '.arion_payment_details_form table th {width:50%}'
                    . '.arion_payment_details_form table td {color:#fff;background-color:#23282D !important}'
                    . '.arion_payment_details_form table th {color:#00ffc6;background-color:#23282D}'
                    . '.arion_payment_details_form table tr {border-bottom:1px solid !important}'
                    . '.arion_payment_details_form table .arion_table_header_row {border-bottom:2px solid !important}'
                    . '.user_arion_address_input,.arion_address_copy{width:100%}'
                    . '.arion_logo_cointainer_div{height:50px;margin-bottom:5px;}'
                    . '.arion_qr_cointainer_div{height:225px;margin-bottom:5px;}'
                    . '.pay_to_right {margin-top: 20px; margin-bottom: 20px;}'
                    . '.arion_payment_details_img{float:left !important;max-height: 100% !important;}'
                    . '.qr_arion_img{float:left !important;max-height: 100% !important;}'
                    . '@media (max-width: 750px) {.pay_to_right{width:100%;float:none}}'
                    . '</style>';
            echo '<div class="arion_logo_cointainer_div">';
            echo '<img class="arion_payment_details_img" src="' . plugins_url( 'img/logo_transparent.png', __FILE__ ) . '" >';
            echo '</div>';
            echo '<div class="arion_payment_details_form">';
            echo '<hr></hr>';
            // ok, let's display some description before the payment form
            if ($this->description) {
                // display the description with <p> tags etc.
                echo wpautop(wp_kses_post($this->description));
            }
            echo '<p class="arion_payment_header"><label>Your Payment Amount In Arion:</label></p>';
            echo '<table>';
            echo '<tr class="arion_table_header_row"><th>Coin</th><th>Total</th></tr>';
            echo '<tr><td>1 x Arion Coin</td><td>'.$currency_symbol.''.$arion_value_in_cur.'</td></tr>';
            echo '<tr><th>Subtotal</th><th>'.$currency_symbol.''.$cart_total.' / ('.$arion_value_in_cur.')</th></tr>';
            echo '<tr><th>Total</th><th>'.$grand_total_in_arion.' ARION COIN</th></tr>';
            echo '</table>';
            echo '<hr></hr>';
            echo '<p><label>Pay To Our Arion Address:</label></p>';
            echo '<div class="arion_qr_cointainer_div">';
            echo '<img class="qr_arion_img" src="https://chart.googleapis.com/chart?chs=225x225&cht=qr&chl=arion-coin:'. $acAdd .'?amount:'.$grand_total_in_arion.'"/>';
            echo '</div>';
            echo '<div class="pay_to_right"><p><label>Copy Receiving Address:</label><input class="arion_address_copy" type="text" value="'.$acAdd.'" readonly></p></div>';
            echo '<hr></hr>';
            echo '<div>';
            echo '<p>';
            echo '<label>Please Enter Your Arion Coin Address Here:(Required)</label>';
            echo '<input id="user_arion_address" class="user_arion_address_input" name="user_arion_address" inputmode="numeric" required  autocorrect="no" autocapitalize="no" spellcheck="no" type="text" placeholder="Please enter your Arion address for reference and incase of refunds" />';
            echo '<input type="hidden" name="one_arion_coin_value" value="'.$arion_value_in_cur.'"/>';
            echo '<input type="hidden" name="sub_total_in_arion" value="'.$cart_total.'"/>';
            echo '<input type="hidden" name="cart_total_in_arion" value="'.$grand_total_in_arion.'"/>';
            echo '</p>';
            echo '</div>';
            
        }

        public function payment_scripts() {
            // Only process if checkout page
            if (!is_cart() && !is_checkout() && !isset($_GET['pay_for_order'])) {
                return;
            }

            // if our payment gateway is disabled, we do not have to enqueue JS too
            if ('no' === $this->enabled) {
                return;
	}
            
        }

        /*
         * Fields validation
         */
        public function validate_fields() {
            if( empty( $_POST[ 'user_arion_address' ]) ) {
		wc_add_notice(  'Your Arion Wallet Address Is Required!', 'error' );
		return false;
	}
	return true;
        }
        
        /*
         * Function to make api call to get current price of arion
         */
        private function get_arion_from_api() {
            $my_woo_store_currency = get_woocommerce_currency();
            $cmc_api_key = $this->cmc_api_key;
            
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?id=3165&convert=$my_woo_store_currency",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "Cache-Control: no-cache",
                    "X-CMC_PRO_API_KEY: $cmc_api_key"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
            } else {
                $getMarket = json_decode( $response );
                $arion_id = 3165;
                $arionMarketPrice = $getMarket->data->$arion_id->quote->$my_woo_store_currency->price;
                return $arionMarketPrice;
            }
        }

        /*
         * We're processing the payments here
         */
        public function process_payment($order_id) {

            global $woocommerce;

            // we need it to get any order detailes
            $order = wc_get_order($order_id);

            // Mark as on-hold (we're awaiting the payment)
            $order->update_status('on-hold', __('Awaiting Arion offline payment', 'wc-gateway-offline'));

            // Reduce stock levels
            $order->reduce_order_stock();
            
            $get_the_customer_arion_payment_amount = get_post_meta( $order_id, 'Cart Total In Arion Coin', true );
            $get_the_customer_arion_address = get_post_meta( $order_id, 'User Arion Address', true );
            
            // some notes to customer (replace true with false to make it private)
            $order->add_order_note('Arion Order Info: Arion Coin payment of '.$get_the_customer_arion_payment_amount.' ARION COIN is pending from customer address: '.$get_the_customer_arion_address.'', false);

            // Empty cart
            $woocommerce->cart->empty_cart();

            // Redirect to the thank you page
            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order)
            );
        }

    }

}
        /**
         * Update the order meta with store location pickup value
         * */
        add_action('woocommerce_checkout_update_order_meta', 'arion_details_fields_update_order_meta');

        function arion_details_fields_update_order_meta($order_id) {
            if ($_POST['user_arion_address'])
                update_post_meta($order_id, 'User Arion Address', esc_attr($_POST['user_arion_address']));
            if ($_POST['one_arion_coin_value'])
                update_post_meta($order_id, '1x Arion Value', esc_attr($_POST['one_arion_coin_value']));
            if ($_POST['sub_total_in_arion'])
                update_post_meta($order_id, 'Subtotal Arion Coin', esc_attr($_POST['sub_total_in_arion']));
            if ($_POST['cart_total_in_arion'])
                update_post_meta($order_id, 'Cart Total In Arion Coin', esc_attr($_POST['cart_total_in_arion']));          
        }
        
        /*
        * 
        * Order summary in thank you page
        * 
        * @param type $order
        */
        add_action( 'woocommerce_order_details_after_order_table', 'arion_view_order_and_thankyou_page' );
        function arion_view_order_and_thankyou_page( $order ){   
        $currency_symbol = get_woocommerce_currency_symbol();   
        $check_payment_method = $order->get_payment_method();
        if($check_payment_method == "arioncoinid"){
        ?>
            <h2>Arion Coin Payment Details</h2>
            <table class="woocommerce-table shop_table">
                <thead><tr><th >Coin</th><th>Total</th></tr></thead>
                <tbody>                   
                    <tr><td>1 x Arion Coin</td><td><?php echo $currency_symbol ?><?php echo get_post_meta( $order->id, '1x Arion Value', true ); ?></td></tr>
                    <tr><th>Subtotal</th><th><?php echo $currency_symbol ?><?php echo get_post_meta( $order->id, 'Subtotal Arion Coin', true ); ?>/(<?php echo get_post_meta( $order->id, '1x Arion Value', true ); ?>)</th></tr>
                    <tr><th>Total</th><th><?php echo get_post_meta( $order->id, 'Cart Total In Arion Coin', true ); ?> ARION COIN</th></tr>
                </tbody>
            </table>
            <div style="height: 25px"></div>
        <?php
        }
        }
        
        
        add_action( 'woocommerce_email_after_order_table', 'arion_woocommerce_email_after_order_table', 10, 1 ); 
        
        function arion_woocommerce_email_after_order_table( $order ){   
         $currency_symbol = get_woocommerce_currency_symbol();
         $check_payment_method = $order->get_payment_method();
            
         if($check_payment_method == "arioncoinid"){
         $text_align = is_rtl() ? 'right' : 'left';
        ?>         
            <h2>Arion Coin Payment Details</h2>
            <div style="margin-bottom: 40px;">
            <table  class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="1">
                <thead>
                    <tr>
                        <th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Coin</th>
                        <th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Quantity</th>
                        <th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Total</th>
                    </tr>
                </thead>
                <tbody>                   
                    <tr>
                        <td class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Arion Coin</td>
                        <td class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">1</td>
                        <td class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo $currency_symbol ?><?php echo get_post_meta( $order->id, '1x Arion Value', true ); ?></td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr><th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Subtotal:</th><th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo $currency_symbol ?><?php echo get_post_meta( $order->id, 'Subtotal Arion Coin', true ); ?>/(<?php echo get_post_meta( $order->id, '1x Arion Value', true ); ?>)</th></tr>                   
                    <tr><th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Total:</th><th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_post_meta( $order->id, 'Cart Total In Arion Coin', true ); ?> ARION COIN</th></tr>
                </tfoot>
            </table>
            </div>
        <?php
        }
        }
        
        // display the extra data in the order admin panel
        add_action('woocommerce_admin_order_data_after_order_details', 'arion_display_order_data_in_admin');
        
        function arion_display_order_data_in_admin($order) {
            $check_payment_method = $order->get_payment_method();
            if($check_payment_method == "arioncoinid"){
                ?>
            <div style="width:100%" class="order_data_column">
                    <h4><?php _e('Customer Arion Details'); ?></h4>                 
                    <p>
                        <label>Arion Wallet Address:</label>
                        <label><?php echo get_post_meta( $order->id, 'User Arion Address', true ); ?></label>
                    </p>
                    <p>
                        <label>Arion Value For Customer Order:</label>
                        <label>1 = <?php echo get_post_meta( $order->id, '1x Arion Value', true ); ?></label>
                    </p>

                </div>  
        <?php
             }
        }
        
        // display the arion total in admin order review page
        add_action('woocommerce_admin_order_totals_after_total', 'arion_admin_order_totals_after_total', 10, 1);

        function arion_admin_order_totals_after_total($order_id) {
            $get_the_payment_method = get_post_meta( $order_id, '_payment_method', true );
            
            if($get_the_payment_method == "arioncoinid"){
                
            // Here set your data and calculations
            $label = __('Arion Total', 'woocommerce');
            $order = wc_get_order( $order_id );
            $get_this_order_status = $order->get_status();
            // Output
            ?>
                    <tr>
                        <td class="label"><?php echo $label; ?>:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <?php if($get_this_order_status == "refunded"){ ?>
                            <del><?php echo get_post_meta( $order_id , 'Cart Total In Arion Coin', true ); ?> Arion</del>
                            <?php } else{ ?>                            
                            <span class="woocommerce-Price-amount amount"><?php echo get_post_meta( $order_id , 'Cart Total In Arion Coin', true ); ?> Arion</span>
                            <?php } ?>
                        </td>
                    </tr>
            <?php
            } 
        }
        
        // display the refunded arion total in admin order review page
        add_action('woocommerce_admin_order_totals_after_refunded', 'arion_admin_order_totals_after_refunded', 10, 1);

        function arion_admin_order_totals_after_refunded($order_id) {
            $get_the_payment_method = get_post_meta( $order_id, '_payment_method', true );
            
            if($get_the_payment_method == "arioncoinid"){
            $order = wc_get_order( $order_id );
            $get_this_order_status = $order->get_status();
            if($get_this_order_status == "refunded"){
            // Here set your data and calculations
            $label = __('Refunded Arion', 'woocommerce');
            
            // Output
            ?>
                    <tr>
                        <td class="label refunded-total"><?php echo $label; ?>:</td>
                        <td width="1%"></td>
                        <td class="total refunded-total"><span class="woocommerce-Price-amount amount">-<?php echo get_post_meta( $order_id , 'Cart Total In Arion Coin', true ); ?> Arion</span></td>
                    </tr>
            <?php
            } 
            }
        }
